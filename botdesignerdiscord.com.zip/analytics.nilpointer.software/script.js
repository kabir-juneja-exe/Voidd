! function() {
    "use strict";
    (t => {
        const {
            screen: {
                width: e,
                height: a
            },
            navigator: {
                language: r,
                doNotTrack: n,
                msDoNotTrack: i
            },
            location: o,
            document: c,
            history: s,
            top: u,
            doNotTrack: d
        } = t, {
            currentScript: l,
            referrer: f
        } = c;
        if (!l) return;
        const {
            hostname: h,
            href: m,
            origin: p
        } = o, y = m.startsWith("data:") ? void 0 : t.localStorage, g = "data-", b = "true", $ = l.getAttribute.bind(l), v = $(`${g}website-id`), w = $(`${g}host-url`), S = $(`${g}before-send`), k = $(`${g}tag`) || void 0, N = "false" !== $(`${g}auto-track`), T = $(`${g}do-not-track`) === b, A = $(`${g}exclude-search`) === b, j = $(`${g}exclude-hash`) === b, x = $(`${g}domains`) || "", L = $(`${g}fetch-credentials`) || "omit", E = x.split(",").map(t => t.trim()), K = `${(w||""||l.src.split("/").slice(0,-1).join("/")).replace(/\/$/,"")}/api/send`, O = `${e}x${a}`, U = /data-umami-event-([\w-_]+)/, _ = `${g}umami-event`, D = 300, P = t => {
            if (!t) return t;
            try {
                const e = new URL(t, o.href);
                return A && (e.search = ""), j && (e.hash = ""), e.toString()
            } catch {
                return t
            }
        }, R = () => ({
            website: v,
            screen: O,
            language: r,
            title: c.title,
            hostname: h,
            url: G,
            referrer: H,
            tag: k,
            id: F || void 0
        }), W = (t, e, a) => {
            a && (H = G, G = P(new URL(a, o.href).toString()), G !== H && setTimeout(J, D))
        }, B = () => Q || !v || y ? .getItem("umami.disabled") || x && !E.includes(h) || T && (() => {
            const t = d || n || i;
            return 1 === t || "1" === t || "yes" === t
        })(), C = async (e, a = "event") => {
            if (B()) return;
            const r = t[S];
            if ("function" == typeof r && (e = await Promise.resolve(r(a, e))), e) try {
                const t = await fetch(K, {
                        keepalive: !0,
                        method: "POST",
                        body: JSON.stringify({
                            type: a,
                            payload: e
                        }),
                        headers: {
                            "Content-Type": "application/json",
                            ...void 0 !== z && {
                                "x-umami-cache": z
                            }
                        },
                        credentials: L
                    }),
                    r = await t.json();
                r && (Q = !!r.disabled, z = r.cache)
            } catch (t) {}
        }, I = () => {
            M || (M = !0, J(), (() => {
                const t = (t, e, a) => {
                    const r = t[e];
                    return (...e) => (a.apply(null, e), r.apply(t, e))
                };
                s.pushState = t(s, "pushState", W), s.replaceState = t(s, "replaceState", W)
            })(), (() => {
                const t = async t => {
                    const e = t.getAttribute(_);
                    if (e) {
                        const a = {};
                        return t.getAttributeNames().forEach(e => {
                            const r = e.match(U);
                            r && (a[r[1]] = t.getAttribute(e))
                        }), J(e, a)
                    }
                };
                c.addEventListener("click", async e => {
                    const a = e.target,
                        r = a.closest("a,button");
                    if (!r) return t(a);
                    const {
                        href: n,
                        target: i
                    } = r;
                    if (r.getAttribute(_)) {
                        if ("BUTTON" === r.tagName) return t(r);
                        if ("A" === r.tagName && n) {
                            const a = "_blank" === i || e.ctrlKey || e.shiftKey || e.metaKey || e.button && 1 === e.button;
                            return a || e.preventDefault(), t(r).then(() => {
                                a || (("_top" === i ? u.location : o).href = n)
                            })
                        }
                    }
                }, !0)
            })())
        }, J = (t, e) => C("string" == typeof t ? { ...R(),
            name: t,
            data: e
        } : "object" == typeof t ? { ...t
        } : "function" == typeof t ? t(R()) : R()), q = (t, e) => ("string" == typeof t && (F = t), z = "", C({ ...R(),
            data: "object" == typeof t ? t : e
        }, "identify"));
        t.umami || (t.umami = {
            track: J,
            identify: q
        });
        let z, F, G = P(m),
            H = P(f.startsWith(p) ? "" : f),
            M = !1,
            Q = !1;
        N && !B() && ("complete" === c.readyState ? I() : c.addEventListener("readystatechange", I, !0))
    })(window)
}();